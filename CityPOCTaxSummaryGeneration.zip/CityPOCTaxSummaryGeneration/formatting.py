def patch_blanks(obj, use_none_for_action_summary=False):
    def patch_value(v):
        fallback = "None" if use_none_for_action_summary else "Not available"
        return fallback if isinstance(v, str) and v.strip().lower() in ["", "none", "not available", "-"] else v

    if isinstance(obj, str):
        return patch_value(obj)
    elif isinstance(obj, list):
        return [patch_blanks(item, use_none_for_action_summary) for item in obj]
    elif isinstance(obj, dict):
        return {k: patch_blanks(v, use_none_for_action_summary) for k, v in obj.items()}
    else:
        return obj