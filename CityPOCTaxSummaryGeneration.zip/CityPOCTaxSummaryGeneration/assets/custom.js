function updateScroll(){
    var element = document.getElementById("display-conversation");
    element.scrollTop = element.scrollHeight;
}

setInterval(updateScroll,100000);