# Block 1 - all imports

import os
import re
import json
from typing import Dict, List, Optional
from datetime import datetime
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer
import openai
from fpdf import FPDF
import pdfplumber
import streamlit as st
from openai import OpenAI
from typing import Dict
import uuid
from PIL import Image
import pytesseract
from langdetect import detect
from typing import Union
from typing import Dict, List, Optional, Union, Any
from formatting import patch_blanks
import copy



# Block 2
# Document type - identification using below function - request or rejection using phrases, the phrases were supplied as addtional inputs to the program

def load_phrase_map(path: str) -> Dict[str, str]:
    phrase_map = {}
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            # Skip empty lines or bad entries
            if "—" in line:
                parts = line.strip().split("—")
                if len(parts) == 2:
                    phrase = parts[0].strip().lower()
                    label = parts[1].strip().lower()
                    if label in ["request", "rejection"]:
                        phrase_map[phrase] = label
    return phrase_map

phrase_map = load_phrase_map("test_data/samples.txt")



def classify_document_type(doc_text: str, phrase_map: Dict[str, str]) -> str:
    normalized = doc_text.lower().replace("\n", " ").replace("\r", " ")
    normalized = re.sub(r"[^\w\s]", " ", normalized)

    for phrase, label in phrase_map.items():
        if phrase in normalized:
            return label

    return "request"  # fallback


# Block 2A: Read pdf, Does OCR for images


def extract_text_from_pdf(pdf_path: str, log_ocr: bool = True) -> str:
    """
    Extract text from a PDF file using pdfplumber, with OCR fallback for image-based pages.
    """
    text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page_num, page in enumerate(pdf.pages, start=1):
            page_text = page.extract_text()
            if page_text:
                text += page_text
            else:
                image = page.to_image(resolution=300).original
                ocr_text = pytesseract.image_to_string(image, lang="deu+eng")  # Add more languages as needed
                # if log_ocr:
                #     st.write(f"🔍 OCR triggered for page {page_num}")
                text += f"\n[OCR Extracted Page {page_num}]\n" + ocr_text
    return text




# Block 3
# Loading the prompts file - request and rejection, handled in Streamlit code


# Block 4
# Semantic Context Retrieval using FAISS

# Block 4A


# Load your embedding model once
embedding_model = SentenceTransformer("all-MiniLM-L6-v2")  # You can swap this with your preferred model

#Convert text into an embedding vector using SentenceTransformer.
def embed_text(text: str):
    return embedding_model.encode([text], convert_to_numpy=True)

# Block 4B
#Retrieve top-k relevant chunks from the corpus using FAISS similarity search.
#this Returns a concatenated string of context.

def retrieve_context(faiss_index, corpus_chunks: List[str], raw_text: str, top_k: int = 5) -> str:
    
    if faiss_index is None or not corpus_chunks:
        return ""

    # Convert raw_text to embedding 
    query_embedding = embed_text(raw_text)  

    # Search FAISS index
    _, indices = faiss_index.search(query_embedding, top_k)

    # Retrieve matching chunks
    matched_chunks = [corpus_chunks[i] for i in indices[0] if i < len(corpus_chunks)]

    return "\n\n".join(matched_chunks)



# Block 5
# LLM Field Extraction

# 5A call_llm function

# Load environment variables from .env file
load_dotenv()

# Fetch API key securely
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
# openai.api_key = os.getenv("OPENAI_API_KEY")


#Send the prompt to OpenAI's LLM and return the response.
def call_llm(prompt: str, model: str = "gpt-4", temperature: float = 0.2) -> str:

    try:
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": "You are a helpful assistant that extracts structured metadata from tax documents."},
                {"role": "user", "content": prompt}
            ],
            temperature=temperature,
            max_tokens=1500
        )
        return response["choices"][0]["message"]["content"]
    except Exception as e:
        print(f"LLM call failed: {e}")
        return ""

# 5B LLM field extraction

def extract_field_llm(response: str) -> dict:
    try:
        parsed = json.loads(response)
        return parsed
    except json.JSONDecodeError:
        return {"Decision": {"Status": "Pending"}, "Confidence": "2/5"}

# Block 6 - Rejection Defaults Handler
#  Apply default values to missing fields in rejection-type documents.
def apply_rejection_defaults(fields: Dict[str, Optional[str]]) -> Dict[str, str]:
    defaults = {
        "Decision": "Reclaim Application Rejected",
        "Preferred Response Mechanism": "Not applicable",
        "Purpose": "Communicate Rejection of Tax Reclaim",
        "Actions": "No further Action required",
        "Action Due Date": "Not applicable",
        "Country of Origin": "Cannot be determined",
        "Source": "Cannot be determined",
        "Tax Filing Reference number": "Cannot be determined",
        "Customer name": "Cannot be determined",
        "Reason for rejection": "Cannot be determined"
    }

    # Fill in missing fields
    for key, default_value in defaults.items():
        if key not in fields or not fields[key]:
            fields[key] = default_value

    return fields


# Block 7 - Request Output Formatter
# Format the output for request-type documents.
# Expects a dictionary with 'Document Summary' and 'Action Summary' already structured.

def format_request_output(fields: Dict[str, Dict]) -> Dict[str, Dict]:
    doc_fields = fields.get("Document Summary", {})
    # 🔒 Whitelist enforcement to prevent field leakage
    allowed_doc_keys = {
        "Language", "Translated to Language", "Sender", "Source",
        "Customer name", "Claim Form Number", "Pay Date", "Reclaim Amount", "Deadline"
    }
    doc_fields = {k: v for k, v in doc_fields.items() if k in allowed_doc_keys}
    action_fields = fields.get("Action Summary", {})

    def safe_get(source: Dict[str, Any], key: str) -> str:
        value = source.get(key)
        if isinstance(value, list) and not value:
            return "None"
        elif isinstance(value, str) and not value.strip():
            return "None"
        elif value is None:
            return "None"
        return value

    def format_action_summary(summary: Dict[str, Any]) -> Dict[str, str]:
        return {
            "Information Required": safe_get(summary, "Information Required"),
            "Documents Required": safe_get(summary, "Documents Required"),
            "Clarification Required": safe_get(summary, "Clarification Required")
        }

    document_summary = {
        "Language": safe_get(doc_fields, "Language"),
        "Translated to Language": safe_get(doc_fields, "Translated to Language"),
        "Sender": safe_get(doc_fields, "Sender"),
        "Source": safe_get(doc_fields, "Source"),
        "Customer name": safe_get(doc_fields, "Customer name"),
        "Claim Form Number": safe_get(doc_fields, "Claim Form Number"),
        "Pay Date": safe_get(doc_fields["Document Summary"], "Date of Claim"),  # ✅ Pull from original
        "Reclaim Amount": safe_get(doc_fields, "Reclaim Amount"),
        "Deadline": safe_get(doc_fields, "Deadline")
    }

    action_summary = format_action_summary(action_fields)

    return {
        "Document Summary": document_summary,
        "Action Summary": action_summary
    }



# Block 8 - Rejection Output Formatter



def format_rejection_output(parsed: dict) -> dict:
    def safe_get(key):
        value = parsed.get(key)
        if isinstance(value, list) and not value:
            return "Not available"
        if isinstance(value, str) and value.strip().lower() in ["", "none", "not applicable", "cannot be determined", "-"]:
            return "Not available"
        if value is None:
            return "Not available"
        return value.strip() if isinstance(value, str) else value

    def format_field(label, value):
        return f"{label}:\n{value}" if value != "Not available" else f"{label}: Not available"

    return {
        "Source": format_field("Source", safe_get("Source")),
        "Country of Origin": format_field("Country of Origin", safe_get("Country of Origin")),
        "Tax Filing Reference number": format_field("Tax Filing Reference number", safe_get("Tax Filing Reference number")),
        "Customer name": format_field("Customer name", safe_get("Customer name")),
        "Decision": format_field("Decision", safe_get("Decision")),
        "Preferred Response Mechanism": format_field("Preferred Response Mechanism", safe_get("Preferred Response Mechanism")),
        "Purpose": format_field("Purpose", safe_get("Purpose")),
        "Actions": format_field("Actions", safe_get("Actions")),
        "Action Due Date": format_field("Action Due Date", safe_get("Action Due Date")),
        "Reason for rejection": format_field("Reason for rejection", safe_get("Reason for rejection"))
    }



# Block 9 - Master Pipeline Function


##################################################################
##################################################################
##################################################################


def process_pdf(doc_text: str, parsed_response: Dict, phrase_map: Dict[str, str]) -> Dict[str, Any]:
    normalized_text = doc_text.lower()
    extracted_fields = parsed_response
    status = "Not available"
    locked_as_rejection = False  

    for phrase, label in phrase_map.items():
        if phrase in normalized_text:
            doc_type = label
            is_rejected = doc_type == "rejection"
            confidence = "5/5"
            break
    else:
        decision = extracted_fields.get("Decision", {})
        if isinstance(decision, dict):
            status = decision.get("Status", "").strip().lower()
            reason = decision.get("Reason", "").strip()
            decision_text = f"{status} {reason}".lower()
        else:
            decision_text = decision.strip().lower()
            status = decision_text
            if "because" in decision_text:
                reason = decision_text.split("because", 1)[-1].strip()
            elif ":" in decision_text:
                reason = decision_text.split(":", 1)[-1].strip()
            else:
                reason = "Not Available"

        strong_rejection_phrases = [
            "rejected", "application not approved", "claim denied", "refund request denied",
            "the claim for refund is thus rejected", "verohallinto ei hyväksy hakemusta", "hylätään"
        ]
        if any(phrase in decision_text for phrase in strong_rejection_phrases):
            doc_type = "rejection"
            is_rejected = True
            confidence = "5/5"
            locked_as_rejection = True
        else:
            doc_type = "rejection" if status == "rejected" else "request"
            is_rejected = doc_type == "rejection"
            confidence = "3/5" if status == "pending" else "2/5"

            rejection_pattern = re.compile(r"\breject(?:ed|ion|s|ing)?\b", re.IGNORECASE)
            text_has_rejection = bool(rejection_pattern.search(normalized_text)) or "ei hyväksytty" in normalized_text
            is_rejected = status == "rejected" or text_has_rejection
            doc_type = "rejection" if is_rejected else "request"

        correction_cues = [
            "opportunity to correct", "deficiencies", "cannot be processed",
            "please resubmit", "submission required"
        ]
        if not locked_as_rejection and doc_type == "rejection" and confidence in ["1/5", "2/5", "3/5"]:
            if any(phrase in normalized_text for phrase in correction_cues):
                doc_type = "request"
                is_rejected = False
                confidence = "4/5"

        if not locked_as_rejection and doc_type == "rejection" and confidence in ["1/5", "2/5"]:
            actions_text = extracted_fields.get("Actions", "").lower()
            if any(verb in actions_text for verb in ["resubmit", "provide", "clarify", "submit", "deadline", "documents"]):
                doc_type = "request"
                is_rejected = False
                confidence = "3/5"

    if status == "pending" or confidence in ["1/5", "2/5"]:
        with open("ambiguous_cases.log", "a", encoding="utf-8") as log:
            log.write(f"\n--- Ambiguous Case ---\n{doc_text[:500]}\nDecision: {status}, Confidence: {confidence}\n")

    # ✅ Only format rejection summaries here
    ####################################################

    if is_rejected:
        formatted = apply_rejection_defaults(parsed_response)
        formatted = sanitize_summary(formatted)
        formatted = format_rejection_output(formatted)
        formatted = patch_blanks(formatted)
    else:
        # ✅ Use flat dictionary directly, no nesting
        formatted = parsed_response.copy()

        # 🔧 Remap new fields
        if "Claim Date" in formatted:
            formatted["Pay Date"] = formatted.pop("Claim Date")

        if "Claim Amount" in formatted:
            formatted["Reclaim Amount"] = formatted.pop("Claim Amount")

        # 🔧 Remove unwanted field if present
        formatted.pop("Deadline Instruction", None)

        # ✅ Patch blanks as usual
        formatted = patch_blanks(formatted, use_none_for_action_summary=True)



    #####################################################

    return {
        "formatted": formatted,
        "is_rejected": is_rejected,
        "doc_type": doc_type
    }


##################################################################
##################################################################
##################################################################


# Block 11: Final Wrapper for Saving Output

def process_pdf_and_save(input_path: str, output_folder: str = "output_files", debug_mode: bool = True) -> dict:
    if debug_mode:
        st.write("Entered process_pdf_and_save() — v2.0")

    # Step 1: Extract raw text
    doc_text = extract_text_from_pdf(input_path)

    # Step 2: Generate LLM summary
    raw_response = call_llm(doc_text)
    try:
        parsed_response = json.loads(raw_response)

        decision_raw = parsed_response.get("Decision", "")
        if isinstance(decision_raw, str):
            status = decision_raw.split(":")[0].strip()
            reason = decision_raw.split(":", 1)[-1].strip() if ":" in decision_raw else "Not Available"
            parsed_response["Decision"] = {
                "Status": status,
                "Reason": reason
            }

        expected_fields = [
            "Source", "Country of Origin", "Tax Filing Reference number", "Customer name",
            "Decision", "Preferred Response Mechanism", "Purpose", "Actions",
            "Action Due Date", "Reason for rejection"
        ]
        for field in expected_fields:
            if field not in parsed_response or not str(parsed_response[field]).strip():
                parsed_response[field] = "Not Available"

        missing_fields = validate_llm_output(parsed_response)
        if missing_fields:
            st.warning(f"Documents Required not found — may be omitted due to prompt phrasing.")

        if debug_mode:
            st.write("Parsed LLM response:")
            st.json(parsed_response)

    except json.JSONDecodeError:
        st.error("Failed to parse LLM output as JSON.")
        return

    if set(parsed_response.keys()) <= {"Decision", "Confidence"}:
        st.warning("LLM did not extract metadata fields. Consider retrying with an enhanced prompt or inspecting the document.")

    if debug_mode:
        st.expander("Raw LLM Response").text(raw_response)

    # Step 3: Intelligent routing
    routing_result = process_pdf(doc_text, parsed_response, phrase_map)
    is_rejected = routing_result["is_rejected"]
    doc_type = routing_result["doc_type"]
    confidence = routing_result["confidence"]

    if debug_mode:
        st.write(f"Routing decision — is_rejected = {is_rejected}")
        st.write(f"Document type: {doc_type}")
        st.write(f"Confidence score: {confidence}")

    # Step 4: Apply fallback logic
    fallback_fields = [
        "Tax Filing Reference number",
        "Preferred Response Mechanism",
        "Action Due Date"
    ]
    for field in fallback_fields:
        if field not in parsed_response or not str(parsed_response[field]).strip():
            parsed_response[field] = "Not Available"

    if "Country of Origin" not in parsed_response or not parsed_response["Country of Origin"].strip():
        parsed_response["Country of Origin"] = "Not Available"

    ref_value = parsed_response.get("Tax Filing Reference number", "")
    if not ref_value or ref_value.strip().lower() in ["", "not applicable", "cannot be determined", "n/a"]:
        match = re.search(r"(Tax Filing Reference|Reference No\.?)[:\s]*([A-Z0-9\-]+)", doc_text, re.IGNORECASE)
        if match:
            parsed_response["Tax Filing Reference number"] = match.group(2)

    if parsed_response.get("Action Due Date", "").lower() in ["", "not applicable"]:
        match = re.search(r"(Action Due Date|Deadline)[:\s]*([0-9]{1,2} [A-Za-z]+ 20[0-9]{2})", doc_text)
        if match:
            parsed_response["Action Due Date"] = match.group(2)

    # Step 5: Translate to English
    parsed_response = translate_summary_to_english(parsed_response)

    if debug_mode:
        st.write("Final Summary with Fallbacks Applied:")
        st.json(parsed_response)

    # Step 6: Build output path
    base_name = os.path.splitext(os.path.basename(input_path))[0]
    unique_id = uuid.uuid4().hex[:8]
    pdf_path = os.path.join(output_folder, f"{base_name}_{unique_id}.pdf")

    # Step 7: Render and Save
    if is_rejected:
        if debug_mode:
            st.write("📄 Entered rejection rendering block")
        formatted = apply_rejection_defaults(parsed_response)
        formatted = sanitize_summary(formatted)
        formatted = format_rejection_output(formatted)
        formatted = patch_blanks(formatted)
        save_rejection_summary_to_pdf(formatted, pdf_path)

    else:
        if debug_mode:
            st.write("@@@@@@@@@@@@@@Entered request rendering block@@@@@@@@@@@@@@@")

        flat_fields = parsed_response.copy()
        flat_fields = translate_summary_to_english(flat_fields)
        for key in ["Type", "Deadline Instruction", "Date of Claim"]:
            flat_fields.pop(key, None)

        allowed_doc_keys = [
            "Language", "Translated to Language", "Sender", "Source",
            "Customer name", "Claim Form Number", "Pay Date", "Reclaim Amount", "Deadline"
        ]

        clean_summary = {
            "Document Summary": {
                key: flat_fields.get(key, "Not available") for key in allowed_doc_keys
            },
            "Action Summary": {
                "Information Required": flat_fields.get("Information Required", []),
                "Documents Required": flat_fields.get("Documents Required", []),
                "Clarification Required": flat_fields.get("Clarification Required", [])
            }
        }

        # Remap Date of Claim to Pay Date
        clean_summary["Document Summary"]["Pay Date"] = flat_fields.get("Date of Claim", "Not available")

        formatted = format_request_output(clean_summary)
        formatted_clean = sanitize_summary(copy.deepcopy(formatted))
        # ✅ Place this line immediately after sanitization
        st.session_state.cleaned_summary = formatted_clean

        doc_summary = formatted_clean["Document Summary"]
        unexpected_fields = [f for f in ["Type", "Deadline Instruction", "Date of Claim"] if f in doc_summary]
        if unexpected_fields:
            st.error(f"❌ Unexpected fields detected in Document Summary: {', '.join(unexpected_fields)}")
            st.json(doc_summary)
            st.session_state.summary_path = None
            return

        st.write("🧪 About to save PDF with:")
        st.json(formatted_clean)
        save_summary_to_pdf(formatted_clean, pdf_path)

    # Step 8: Log blank outputs
    if all(v in ["-", "None", "Not available"] for v in parsed_response.get("Document Summary", {}).values()):
        with open("blank_outputs.log", "a", encoding="utf-8") as log:
            log.write(f"\n--- Blank Output ---\n{input_path}\n{doc_text[:500]}\n")

    if debug_mode:
        st.write("Final Tax Filing Reference number:", parsed_response.get("Tax Filing Reference number", "Missing"))
        st.write("Final Country of Origin:", parsed_response.get("Country of Origin", "Missing"))

    return {
        "pdf": pdf_path,
        "is_rejected": is_rejected,
        "doc_type": doc_type,
        "confidence": confidence
    }




# Block 12: custom class for Save pdf


class SummaryPDF(FPDF):
    #1
    def __init__(self):
        super().__init__()
        self.set_auto_page_break(auto=True, margin=15)
        self.set_margins(left=15, top=15, right=15)
        # ✅ Register and activate Unicode-compatible font
        self.add_font('DejaVu', '', 'ttf/DejaVuSans.ttf', uni=True)
        self.add_font('DejaVu', 'B', 'ttf/DejaVuSans-Bold.ttf', uni=True) 
        self.set_font('DejaVu', '', 12)
    #2 Cleaning process UTF impacted
    def _sanitize_text(self, text):
        replacements = {
            '\u2019': "'", '\u2018': "'", '\u201c': '"', '\u201d': '"',
            '\u2013': '-', '\u2014': '-', '\u2026': '...'
        }

        if text is None:
            text = "—"
        elif isinstance(text, dict):
            text = "\n".join(f"{self._sanitize_text(k)}: {self._sanitize_text(v)}" for k, v in text.items())
        elif isinstance(text, list):
            text = "\n".join(f"{self._sanitize_text(item)}" for item in text)
        elif not isinstance(text, str):
            text = str(text)

        for uni_char, ascii_char in replacements.items():
            text = text.replace(uni_char, ascii_char)

        return text.encode("latin-1", "replace").decode("latin-1")
    
    # def add_page(self):
    #     super().add_page()
    #     self.set_font("Arial", style="B", size=14)
    #     self.cell(0, 10, "Tax Document Summary", ln=True)
    #     self.ln(5)
    #3
    def add_page(self, orientation=''):
        super().add_page(orientation)
        # No heading here — let metadata table handle it

    def header(self):
        pass  # Suppress header entirely
    #5
    def footer(self):
        self.set_y(-15)
        self.set_font("DejaVu", size=8)
        self.set_text_color(128)
        self.cell(0, 10, "Generated by OCR Summarizer", align="C")
    #6 for Final PDF output, medadata table addtion
    def add_metadata_table(self, metadata_dict, title="Document Summary"):

        if not metadata_dict:
            self.set_font("DejaVu", style="B", size=12)
            self.cell(0, 10, "No metadata available", ln=True)
            return

        self.set_font("DejaVu", style="B", size=12)
        self.cell(0, 10, title, ln=True)
        self.set_font("DejaVu", size=11)

        col_width = 75
        line_height = 8

        # Table headers
        self.set_font("DejaVu", style="B", size=11)
        self.cell(col_width, line_height, "Main Attributes", border=1)
        self.cell(0, line_height, "Values", border=1, ln=True)
        self.set_font("DejaVu", size=11)

        missing_keys = [k for k, v in metadata_dict.items() if not v]
        if missing_keys:
            print(f"Missing metadata for: {missing_keys}")

        def clean_value(v):
            return "Not available" if str(v).strip().lower() in ["", "none", "-", "not available"] else v.strip()
        
        def strip_redundant_prefix(key: str, value: str) -> str:
            prefix = f"{key.strip()}:"
            if value.strip().lower().startswith(prefix.lower()):
                return value.strip()[len(prefix):].strip()
            return value


        for key, value in metadata_dict.items():
            raw_value = sanitize_for_pdf(self._sanitize_text(value))
            cleaned_value = clean_value(raw_value)
            value = strip_redundant_prefix(key, cleaned_value)



            if key == "Customer name":
                # Truncate if over 100 characters
                if len(value) > 100:
                    value = value[:100] + "…"

                # Wrap using multi_cell
                self.cell(col_width, line_height, key, border=1)
                self.multi_cell(0, line_height, value, border=1)

                # Remove extra spacing — use consistent line height
                # Do NOT call self.ln(line_height) here

            elif key == "Decision":
                # Render clean single-line decision text
                self.cell(col_width, line_height, key, border=1)
                self.cell(0, line_height, value, border=1, ln=True)

            elif key == "Reclaim Amount":
                amount = value.replace("?", "€")
                self.cell(col_width, line_height, key, border=1)
                self.multi_cell(0, line_height, amount, border=1)

            # elif key == "Preferred Response Mechanism":
            #     self.multi_cell(col_width, line_height, key, border=1, align='L')
            #     self.multi_cell(0, line_height, value, border=1)
                

            elif key == "Reason for rejection":
                # Preserve original layout
                self.cell(col_width, line_height, key, border=1)
                self.multi_cell(0, line_height, value, border=1)
                # self.ln(line_height)

            elif key == "Source":
                self.cell(col_width, line_height, key, border=1)
                self.multi_cell(0, line_height, value, border=1)

            elif key == "Deadline":
                self.cell(col_width, line_height, key, border=1)
                self.multi_cell(0, line_height, value, border=1)

            # elif (len(value) > 80 or "\n" in value) and key != "Decision":
            elif (len(value) > 80 or "\n" in value) and key not in ["Decision", "Source"]:
                # Wrap other long fields
                y_before = self.get_y()
                x_before = self.get_x()

                self.multi_cell(col_width, line_height, key, border=1)
                y_after_key = self.get_y()

                self.set_xy(x_before + col_width, y_before)
                self.multi_cell(0, line_height, value, border=1)

                self.set_y(max(y_after_key, self.get_y()))
                #self.ln(line_height)

            elif (len(value) > 80 or "\n" in value) or key in ["Preferred Response Mechanism"]:
                y_before = self.get_y()
                x_before = self.get_x()

                # Wrap key
                self.multi_cell(col_width, line_height, key, border=1, align='L')
                y_after_key = self.get_y()

                # Wrap value
                self.set_xy(x_before + col_width, y_before)
                self.multi_cell(0, line_height, value, border=1, align='L')

                # Normalize vertical position
                self.set_y(max(y_after_key, self.get_y()))


            else:
                # Single-line rendering
                self.cell(col_width, line_height, key, border=1)
                self.cell(0, line_height, value, border=1, ln=True)
    #7 for Reuqest type - addiotn of Summary Section
    def add_summary_section(self, summary_dict):
        self.ln(10)
        self.set_font("DejaVu", style="B", size=12)
        self.cell(0, 10, "Action Summary", ln=True)
        self.set_font("DejaVu", size=11)

        col_width = 60
        line_height = 8

        # Table headers
        self.set_font("DejaVu", style="B", size=11)
        self.cell(col_width, line_height, "Category", border=1)
        self.cell(0, line_height, "Details", border=1, ln=True)
        self.set_font("DejaVu", size=11)

        for section in ["Information Required", "Documents Required", "Clarification Required"]:
            items = summary_dict.get(section)

            # Normalize
            if isinstance(items, str):
                items = [items]
            elif items is None:
                items = []
            elif not isinstance(items, list):
                items = [str(items)]

            # Filter and combine
            clean_items = [self._sanitize_text(item).strip() for item in items if self._sanitize_text(item).strip() not in ["", "-", "—"]]
            paragraph = " ".join(clean_items)

            x = self.get_x()
            y = self.get_y()
            self.multi_cell(col_width, line_height, self._sanitize_text(section), border=1)
            self.set_xy(x + col_width, y)

            if paragraph:
                self.multi_cell(0, line_height, paragraph, border=1)
            else:
                self.multi_cell(0, line_height, "- None", border=1)

            self.set_y(max(self.get_y(), y + line_height))


######## Save to PDF ########
######## using the SummaryPDF class methods#########


def save_summary_to_pdf(summary: dict, output_path: str):
    if not isinstance(summary, dict):
        st.error("❌ Invalid summary passed to PDF generator. Expected a dictionary.")
        return

    # ✅ Validate presence of expected flat keys
    required_keys = [
        "Language", "Translated to Language", "Sender", "Source",
        "Customer name", "Claim Form Number", "Deadline",
        "Pay Date", "Reclaim Amount",
        "Information Required", "Documents Required", "Clarification Required"
    ]
    missing_keys = [k for k in required_keys if k not in summary]
    if missing_keys:
        # st.warning(f"⚠️ Summary missing fields: {', '.join(missing_keys)}")
        st.warning("Documents Required not found — may be omitted due to prompt phrasing.")


    # 🔍 Field leakage checks
    for field in ["Type", "Deadline Instruction", "Date of Claim"]:
        if field in summary:
            st.error(f"❌ Unexpected field detected: '{field}' in summary")
            st.json(summary)
            return

    pdf = SummaryPDF()
    pdf.doc_type = "request"
    pdf.add_page()
    # pdf.set_font("Arial", size=12)
    # Use Unicode-compatible font
    pdf.add_font('DejaVu', '', 'ttf/DejaVuSans.ttf', uni=True)
    pdf.set_font('DejaVu', '', 12)

    # Split flat summary into display sections
    doc_fields = [
        "Language", "Translated to Language", "Sender", "Source",
        "Customer name", "Claim Form Number", "Deadline",
        "Pay Date", "Reclaim Amount"
    ]
    doc_summary = {k: summary.get(k, "Not available") for k in doc_fields}

    action_summary = {
        "Information Required": summary.get("Information Required", "None"),
        "Documents Required": summary.get("Documents Required", "None"),
        "Clarification Required": summary.get("Clarification Required", "None")
    }

    # Render using modular methods
    pdf.add_metadata_table(doc_summary, title="Document Summary")
    pdf.add_summary_section(action_summary)

    # Debug dump for inspection
    with open("pdf_debug_dump.txt", "w", encoding="utf-8") as f:
        for page in pdf.pages:
            f.write(str(page) + "\n\n")

    # Save PDF
    try:
        pdf.output(output_path)
    except UnicodeEncodeError as e:
        st.error(f"PDF generation failed: {e}")
        with open("unicode_errors.log", "a", encoding="utf-8") as log:
            log.write(f"\n--- Unicode Error ---\nFile: {output_path}\nError: {str(e)}\n")




# Block 13:   saving rejection summary
# table - type - Rejection
def save_rejection_summary_to_pdf(summary: dict, output_path: str):
    # st.write("Inside save_rejection_summary_to_pdf")
    # st.expander("📄 PDF Renderer Received").json(summary)
    try:
        # st.write("About to create PDF object")
        pdf = SummaryPDF()
        pdf.doc_type = "rejection"  
        pdf.add_page()
        # ✅ Use Unicode-compatible font
        pdf.add_font('DejaVu', '', 'ttf/DejaVuSans.ttf', uni=True)
        pdf.set_font('DejaVu', '', 12)

        def clean_value(v):
            return "Not available" if str(v).strip().lower() in ["", "none", "-", "not available"] else v

        metadata_for_table = {
            "Source": clean_value(summary.get("Source")),
            "Country of Origin": clean_value(summary.get("Country of Origin")),
            "Tax Filing Reference number": clean_value(summary.get("Tax Filing Reference number")),
            "Customer name": clean_value(summary.get("Customer name")),
            "Decision": "Reclaim Application Rejected",  
            "Preferred Response Mechanism": "Not applicable",
            "Purpose": "Communicate Rejection of Tax Reclaim",
            "Actions": "No further Action required",
            "Action Due Date": "Not applicable",
            "Reason for rejection": clean_value(summary.get("Reason for rejection"))
        }


        pdf.add_metadata_table(metadata_for_table, title="Document Summary")

        # Only add action section if relevant
        if "Action Summary" in summary and any(summary["Action Summary"].values()):
            pdf.add_summary_section(summary["Action Summary"])

        # st.write("PDF rendering complete for rejection document")
        # st.write("I am here at rejection end..")
        pdf.output(output_path)
    except Exception as e:
        st.error(f"PDF generation failed: {e}")

#To retrieve metadata fields from a parsed dictionary while filtering out not required fields
def safe_get(parsed, key):
    value = parsed.get(key)
    if value and value.strip().lower() not in ["none", "not applicable", "Cannot be determined"]:
        return value
    return "Not available"



def translate_text(text: str, target_lang: str = "en") -> str:
    try:
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": f"Translate the following text to {target_lang}."},
                {"role": "user", "content": text}
            ],
            temperature=0.2,
            max_tokens=1000
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        print(f"Translation failed: {e}")
        return text


#convert summary to english
def translate_summary_to_english(summary: dict) -> dict:
    force_translate_keys = {
        "Information Required", "Documents Required", "Clarification Required",
        "Purpose", "Reason for rejection", "Actions"
    }

    def translate_value(value: Union[str, list, dict], key: Optional[str] = None) -> Union[str, list, dict]:
        if isinstance(value, str):
            try:
                if key in force_translate_keys:
                    translated = translate_text(value, target_lang="en")
                    st.write(f"🔄 Forced translation for {key}: {value[:50]} → {translated[:50]}")
                    return translated
                lang = detect(value)
                if lang != "en":
                    translated = translate_text(value, target_lang="en")
                    st.write(f"🔄 Translated from {lang}: {value[:50]} → {translated[:50]}")
                    return translated
            except Exception as e:
                print(f"Translation error for {key}: {e}")
            return value
        elif isinstance(value, list):
            return [translate_value(item, key) for item in value]
        elif isinstance(value, dict):
            return {k: translate_value(v, k) for k, v in value.items()}
        else:
            return value

    return translate_value(summary)



#loading phrases for Request type
def load_request_phrases(path="test_data/samples.txt") -> List[str]:
    phrases = []
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip().lower()
                if line and ("request for additional" in line or "lisätietoja" in line or "anmodning" in line):
                    phrases.append(line)
    return list(set(phrases))

# to clean and normalize text before it's embedded into a PDF
def sanitize_for_pdf(text: str) -> str:
    if not isinstance(text, str):
        text = str(text)
    # Replace known problematic characters
    replacements = {
        "’": "'",
        "‘": "'",
        "“": '"',
        "”": '"',
        "–": "-",
        "—": "-",
        "•": "-",
        "…": "...",
        "©": "(c)",
        "®": "(R)",
        "™": "(TM)",
        "€": "EUR",
        "£": "GBP",
        "→": "->",
        "←": "<-",
        "°": " degrees",
        "✓": "check",
        "✔": "check",
        "×": "x",
        "•": "-",
    }
    for bad, good in replacements.items():
        text = text.replace(bad, good)
    # Remove any remaining non-latin-1 characters
    return text.encode("latin-1", "replace").decode("latin-1")

#validate schema for Request and Rejection type documents
def validate_llm_output(parsed):
    required_keys = [
        "Source", "Country of Origin", "Tax Filing Reference number", "Customer name",
        "Decision", "Reason for rejection"
    ]
    missing = [k for k in required_keys if k not in parsed or not parsed[k]]
    return missing

# cleaning the summary text before putting to pdf
def sanitize_summary(summary: dict) -> dict:
    def sanitize(obj):
        if isinstance(obj, str):
            return sanitize_for_pdf(obj)
        elif isinstance(obj, list):
            return [sanitize(item) for item in obj]
        elif isinstance(obj, dict):
            return {k: sanitize(v) for k, v in obj.items()}
        else:
            return sanitize_for_pdf(str(obj))

    return sanitize(summary)

# added to handle non latin characters
def safe_cell(pdf, *args, **kwargs):
    if "txt" in kwargs:
        kwargs["txt"] = sanitize_for_pdf(kwargs["txt"])
    elif len(args) >= 3:
        args = list(args)
        args[2] = sanitize_for_pdf(str(args[2]))
    return pdf.cell(*args, **kwargs)
# added to handle non latin characters
def safe_multi_cell(pdf, *args, **kwargs):
    if "txt" in kwargs:
        kwargs["txt"] = sanitize_for_pdf(kwargs["txt"])
    elif len(args) >= 3:
        args = list(args)
        args[2] = sanitize_for_pdf(str(args[2]))
    return pdf.multi_cell(*args, **kwargs)

