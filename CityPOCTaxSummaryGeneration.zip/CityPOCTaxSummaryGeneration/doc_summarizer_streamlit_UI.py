import streamlit as st
from process_documents import (
    extract_text_from_pdf,
    load_phrase_map,
    classify_document_type,
    process_pdf,
    save_summary_to_pdf,
    save_rejection_summary_to_pdf
)
from formatting import patch_blanks
import os
import json
from openai import OpenAI
import uuid

# 🔄 Reset logic
if "reset_triggered" in st.session_state and st.session_state.reset_triggered:
    summary_path = st.session_state.get("summary_path")
    if summary_path and os.path.exists(summary_path):
        os.remove(summary_path)
    for key in list(st.session_state.keys()):
        del st.session_state[key]
    st.session_state.reset_triggered = False
    st.rerun()

# 🧠 Session state init
if "file_uploader_key" not in st.session_state:
    st.session_state.file_uploader_key = "initial"
if "uploaded_path" not in st.session_state:
    st.session_state.uploaded_path = None
    st.session_state.doc_text = None
    st.session_state.doc_type = None
    st.session_state.summary_path = None
    st.session_state.processed_text = ""
    st.session_state.cleaned_summary_dict = None
    st.session_state.cleaned_summary_text = ""

# 🔍 Load phrase map
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
phrase_map = load_phrase_map("test_data/samples.txt")

# 🖼️ UI setup
st.set_page_config(page_title="Request and Rejection Tax Document Summarizer", page_icon="📄", layout="centered")
st.markdown("<h1 style='text-align: center;'>📄 Request and Rejection Tax Document Summarizer</h1>", unsafe_allow_html=True)
st.markdown("<p style='text-align: center;'>Upload a tax document and generate a clean summary PDF.</p>", unsafe_allow_html=True)

# 📤 Upload section
uploaded_file = st.file_uploader("Upload PDF", type=["pdf"], label_visibility="collapsed", key=st.session_state.file_uploader_key)

if uploaded_file:
    for f in os.listdir("input_files"):
        os.remove(os.path.join("input_files", f))
    input_path = f"input_files/{uploaded_file.name}"
    with open(input_path, "wb") as f:
        f.write(uploaded_file.getbuffer())
    st.session_state.uploaded_path = input_path
    raw_text = extract_text_from_pdf(input_path)
    cleaned_text = raw_text.replace("[OCR Extracted Page 1]", "").replace("Machine Translated by Google", "").strip()
    st.session_state.doc_text = cleaned_text
    st.session_state.doc_type = classify_document_type(cleaned_text, phrase_map)
    st.success("✅ Document uploaded successfully.")

# 🔄 Reset button
if st.button("🔄 Reset Page"):
    st.session_state.reset_triggered = True
    st.session_state.file_uploader_key = str(uuid.uuid4())
    st.rerun()

# 🖥️ Side-by-side text boxes
if st.session_state.doc_text:
    col1, col2 = st.columns(2)
    with col1:
        st.text_area("📄 Original Document Text", value=st.session_state.doc_text, height=400, disabled=True)
    with col2:
        st.text_area("📝 Processed Summary", value=st.session_state.processed_text, height=400, disabled=True)

# 📄 Process button
if st.session_state.uploaded_path:
    if st.button("📄 Process the document"):
        with st.spinner("Processing..."):
            st.session_state.cleaned_summary_text = ""
            st.session_state.cleaned_summary_dict = None
            st.session_state.summary_path = None

            # ✅ Re-run your processing logic here
            prompt_path = os.path.join("prompts", f"{st.session_state.doc_type}_enhanced.txt")
            with open(prompt_path, "r", encoding="utf-8") as f:
                prompt = f.read()
            full_prompt = f"{prompt}\n```\n{st.session_state.doc_text}\n```"

            response = client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are a helpful assistant that extracts structured metadata from tax documents."},
                    {"role": "user", "content": full_prompt}
                ],
                temperature=0.2,
                max_tokens=1500
            )

            raw = response.choices[0].message.content
            # st.write("🧪 Raw LLM Output:")
            # st.text(raw)
            try:
                parsed = json.loads(raw)
                # st.write("🔍 Parsed Summary:")
                # st.json(parsed)
            except json.JSONDecodeError:
                parsed = {}

            result = process_pdf(st.session_state.doc_text, parsed, phrase_map)
            summary = result["formatted"]
            # 🔧 Flatten nested summary if needed
            if "Document Summary" in summary and "Action Summary" in summary:
                summary = {
                    **summary["Document Summary"],
                    **summary["Action Summary"]
                }
            is_rejected = result["is_rejected"]
            

            output_path = f"output_files/{uploaded_file.name.split('.')[0]}_summary.pdf"

            if summary is None or not isinstance(summary, dict):
                st.error("❌ No valid summary returned. Cannot proceed.")
                st.session_state.cleaned_summary_dict = None
                st.session_state.cleaned_summary_text = ""
                st.stop()

            formatted_clean = patch_blanks(summary.copy(), use_none_for_action_summary=True)

            # 🔧 Remove Deadline Instruction if present
            if "Deadline Instruction" in formatted_clean:
                del formatted_clean["Deadline Instruction"]

            # 🔧 Also check nested Action Summary block
            if isinstance(formatted_clean.get("Action Summary"), dict):
                formatted_clean["Action Summary"].pop("Deadline Instruction", None)

            # 🔧 Remap Claim Date → Pay Date
            if "Claim Date" in formatted_clean:
                formatted_clean["Pay Date"] = formatted_clean.pop("Claim Date")

            # 🔧 Remap Claim Amount → Reclaim Amount
            if "Claim Amount" in formatted_clean:
                formatted_clean["Reclaim Amount"] = formatted_clean.pop("Claim Amount")


            st.session_state.cleaned_summary_dict = formatted_clean
            st.session_state.summary_path = output_path

            # 🧾 Save PDF
            if is_rejected:
                save_rejection_summary_to_pdf(formatted_clean, output_path)
            else:
                save_summary_to_pdf(formatted_clean, output_path)

            # 🖥️ Display logic
            if is_rejected:
                display_fields = [
                    "Source", "Country of Origin", "Tax Filing Reference number", "Customer name",
                    "Decision", "Preferred Response Mechanism", "Purpose", "Actions",
                    "Action Due Date", "Reason for rejection"
                ]
                def strip_label(k, v):
                    v = str(v).strip()
                    if v.lower().startswith(k.lower() + ":"):
                        return v[len(k)+1:].strip()
                    return v
                display_summary = {k: strip_label(k, formatted_clean.get(k, "Not available")) for k in display_fields}
                st.session_state.cleaned_summary_text = "\n".join(f"{k}: {v}" for k, v in display_summary.items())
            else:
                st.session_state.cleaned_summary_text = json.dumps(formatted_clean, indent=2, ensure_ascii=False)

            st.session_state.processed_text = st.session_state.cleaned_summary_text
            st.success("✅ Summary generated.")

# 🪄 Display + 📥 Download buttons
if st.session_state.cleaned_summary_text:
    if st.button("🪄 Display Summary"):
        st.session_state.processed_text = st.session_state.cleaned_summary_text
    if st.session_state.summary_path and os.path.exists(st.session_state.summary_path):
        with open(st.session_state.summary_path, "rb") as f:
            st.download_button("📥 Download Summary", f, file_name=os.path.basename(st.session_state.summary_path))
    else:
        st.warning("⚠️ Summary was generated but not saved due to validation errors or missing file.")





# import streamlit as st
# from process_documents import (
#     extract_text_from_pdf,
#     load_phrase_map,
#     classify_document_type,
#     process_pdf,
#     save_summary_to_pdf,
#     save_rejection_summary_to_pdf
# )
# from formatting import patch_blanks
# import os
# import json
# from openai import OpenAI
# import uuid


# #################################################

# # Handle full reset before anything else
# if "reset_triggered" in st.session_state and st.session_state.reset_triggered:
#     # Delete generated summary file if it exists
#     summary_path = st.session_state.get("summary_path")
#     if summary_path and os.path.exists(summary_path):
#         os.remove(summary_path)

#     # Clear session state
#     for key in list(st.session_state.keys()):
#         del st.session_state[key]

#     st.session_state.reset_triggered = False
#     st.rerun()

# if "file_uploader_key" not in st.session_state:
#     st.session_state.file_uploader_key = "initial"

# ###########################################

# client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# # Load phrase map once at startup
# phrase_map = load_phrase_map("test_data/samples.txt")

# # UI setup
# st.set_page_config(page_title="Request and Rejection Tax Document Summarizer", page_icon="📄", layout="centered")
# st.markdown("<h1 style='text-align: center;'>📄 Request and Rejection Tax Document Summarizer</h1>", unsafe_allow_html=True)
# st.markdown("<p style='text-align: center;'>Upload a tax document and generate a clean summary PDF.</p>", unsafe_allow_html=True)

# # Session state initialization
# if "uploaded_path" not in st.session_state:
#     st.session_state.uploaded_path = None
#     st.session_state.doc_text = None
#     st.session_state.doc_type = None
#     st.session_state.summary_path = None
#     st.session_state.processed_text = ""
#     st.session_state.cleaned_summary_dict = None
#     st.session_state.cleaned_summary_text = ""

# # 📤 Upload section
# uploaded_file = st.file_uploader("Upload PDF", type=["pdf"], label_visibility="collapsed", key=st.session_state.file_uploader_key)

# if uploaded_file:
#     # Refresh input_files folder
#     for f in os.listdir("input_files"):
#         os.remove(os.path.join("input_files", f))

#     input_path = f"input_files/{uploaded_file.name}"
#     with open(input_path, "wb") as f:
#         f.write(uploaded_file.getbuffer())

#     st.session_state.uploaded_path = input_path
#     raw_text = extract_text_from_pdf(input_path)
#     cleaned_text = raw_text.replace("[OCR Extracted Page 1]", "").replace("Machine Translated by Google", "").strip()
#     st.session_state.doc_text = cleaned_text
#     st.session_state.doc_type = classify_document_type(cleaned_text, phrase_map)

#     st.success("✅ Document uploaded successfully.")

# # 🔄 Reset button to refresh the page
# if st.button("🔄 Reset Page"):
#     st.session_state.reset_triggered = True
#     st.session_state.file_uploader_key = str(uuid.uuid4())  # Force re-render
#     st.rerun()

# # 🖥️ Side-by-side text boxes
# if st.session_state.doc_text:
#     col1, col2 = st.columns(2)

#     with col1:
#         st.text_area(
#             "📄 Original Document Text",
#             value=st.session_state.doc_text,
#             height=400,
#             disabled=True
#         )

#     with col2:
#         st.text_area(
#             "📝 Processed Summary",
#             value=st.session_state.processed_text,
#             height=400,
#             disabled=True
#         )

# # 📄 Process button (only before processing)
# if st.session_state.uploaded_path and not st.session_state.cleaned_summary_text:
#     if st.button("📄 Process the document"):
#         with st.spinner("Processing..."):
#             enhanced_prompt_path = os.path.join("prompts", f"{st.session_state.doc_type}_enhanced.txt")
#             with open(enhanced_prompt_path, "r", encoding="utf-8") as f:
#                 enhanced_prompt = f.read()

#             full_prompt = f"{enhanced_prompt}\n```\n{st.session_state.doc_text}\n```"

#             retry_response = client.chat.completions.create(
#                 model="gpt-4",
#                 messages=[
#                     {"role": "system", "content": "You are a helpful assistant that extracts structured metadata from tax documents."},
#                     {"role": "user", "content": full_prompt}
#                 ],
#                 temperature=0.2,
#                 max_tokens=1500
#             )

#             raw_retry = retry_response.choices[0].message.content
#             try:
#                 parsed_retry = json.loads(raw_retry)
#             except json.JSONDecodeError:
#                 parsed_retry = {}

#             # Field Recovery Block
#             missing_fields = []
#             for key in ["Source", "Customer name", "Reason for rejection"]:
#                 if parsed_retry.get(key, "").lower() in ["", "not available", "none"]:
#                     missing_fields.append(key)

#             if missing_fields:
#                 with open("prompts/field_recovery.txt", "r", encoding="utf-8") as f:
#                     recovery_prompt = f.read()

#                 full_prompt = f"{recovery_prompt}\n```\n{st.session_state.doc_text}\n```"

#                 recovery_response = client.chat.completions.create(
#                     model="gpt-4",
#                     messages=[
#                         {"role": "system", "content": "You are a helpful assistant that extracts missing metadata from tax documents."},
#                         {"role": "user", "content": full_prompt}
#                     ],
#                     temperature=0.2,
#                     max_tokens=800
#                 )

#                 recovered_fields = json.loads(recovery_response.choices[0].message.content)

#                 for key in missing_fields:
#                     parsed_retry[key] = recovered_fields.get(key, "Not available")

#                 reason = parsed_retry.get("Reason for rejection", "")
#                 if "(" in reason and ")" in reason:
#                     english_only = reason.split("(", 1)[-1].split(")", 1)[0].strip()
#                     if len(english_only.split()) > 4:
#                         parsed_retry["Reason for rejection"] = english_only

#             result = process_pdf(st.session_state.doc_text, parsed_retry, phrase_map)
#             summary = result["formatted"]
#             is_rejected = result["is_rejected"]

#             output_path = f"output_files/{uploaded_file.name.split('.')[0]}_summary.pdf"

#             # Build clean summary for PDF


#             summary_dict = st.session_state.cleaned_summary_dict
#             if not isinstance(summary_dict, dict):
#                 st.error("❌ cleaned_summary_dict is not a valid dictionary. Cannot proceed.")
#                 st.write("🧪 Current value of cleaned_summary_dict:")
#                 st.write(summary_dict)
#                 st.stop()
#             formatted_clean = patch_blanks(summary_dict.copy(), use_none_for_action_summary=True)
            

#             st.session_state.cleaned_summary_dict = formatted_clean

#             # Save PDF
#             if is_rejected:
#                 save_rejection_summary_to_pdf(formatted_clean, output_path)
#             else:
#                 save_summary_to_pdf(formatted_clean, output_path)

#             st.session_state.summary_path = output_path

#             formatted_clean = st.session_state.cleaned_summary
#             if is_rejected:
#                 save_rejection_summary_to_pdf(formatted_clean, output_path)
#             else:
#                 save_summary_to_pdf(formatted_clean, output_path)

#             st.session_state.summary_path = output_path 
                
#             clean_summary = formatted_clean.copy()
#             patched_summary = patch_blanks(clean_summary, use_none_for_action_summary=True)
#             formatted_summary = patched_summary

#             if is_rejected:
#                 display_fields = [
#                     "Source",
#                     "Country of Origin",
#                     "Tax Filing Reference number",
#                     "Customer name",
#                     "Decision",
#                     "Preferred Response Mechanism",
#                     "Purpose",
#                     "Actions",
#                     "Action Due Date",
#                     "Forward to operator",
#                     "Reason for rejection"
#                 ]

#                 def strip_label(k, v):
#                     v = str(v).strip()
#                     if v.lower().startswith(k.lower() + ":"):
#                         return v[len(k)+1:].strip()
#                     return v

#                 display_summary = {
#                     k: strip_label(k, formatted_summary.get(k, "Not available")) for k in display_fields
#                 }

#                 st.session_state.cleaned_summary_text = "\n".join(
#                     f"{k}: {v}" for k, v in display_summary.items()    
#                 )
#             else:
#                 # Remove top-level duplicates
#                 clean_summary = {k: v for k, v in summary.items() if k not in ["Confidence", "Source", "Customer name", "Reason for rejection"]}

#                 # Patch blanks recursively
#                 patched_summary = patch_blanks(clean_summary)

#                 # Store for display
#                 st.session_state.cleaned_summary_text = json.dumps(patched_summary, indent=2)
#                 # st.session_state.cleaned_summary = json.dumps(formatted_summary, indent=2)


#             st.session_state.processed_text = st.session_state.cleaned_summary

#             # 🧾 Save PDF
#             if is_rejected:
#                 save_rejection_summary_to_pdf(formatted_summary, output_path)
#             else:
#                 save_summary_to_pdf(formatted_summary, output_path)

#             st.success("✅ Summary generated.")


# # 🪄 Display + 📥 Download buttons (only after processing)
# if st.session_state.cleaned_summary_text:
#     if st.button("🪄 Display Summary"):
#         st.session_state.processed_text = st.session_state.cleaned_summary_text

#     if st.session_state.summary_path and os.path.exists(st.session_state.summary_path):
#         with open(st.session_state.summary_path, "rb") as f:
#             st.download_button(
#                 "📥 Download Summary",
#                 f,
#                 file_name=os.path.basename(st.session_state.summary_path)
#             )
#     else:
#         st.warning("⚠️ Summary was generated but not saved due to validation errors or missing file.")



